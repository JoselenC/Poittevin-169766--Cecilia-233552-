﻿using System.Collections.Generic;
using MSP.BetterCalm.Importer;


namespace MSP.BetterCalm.WebAPI.Dtos
{
    public class ImportDto
    {
        public string Name { get; set; }
        
        public string Path { get; set; }
    }
}