namespace MSP.BetterCalm.Domain
{
    public abstract class User
    {
        public string Name { get; set; }
        public string LastName { get; set; }

    }
}