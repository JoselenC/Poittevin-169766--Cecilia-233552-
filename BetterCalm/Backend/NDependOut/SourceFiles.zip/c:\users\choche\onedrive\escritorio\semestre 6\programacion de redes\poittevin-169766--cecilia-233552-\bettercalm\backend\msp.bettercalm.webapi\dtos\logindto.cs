namespace MSP.BetterCalm.WebAPI.Dtos
{
    public class LoginDto
    {
        public string email { get; set; }
        public string password { get; set; }
        public string token { get; set; }
    }
}