﻿using System.Collections.Generic;

namespace MSP.BetterCalm.Importer
{
    public class Import
    {
        public string Name { get; set; }
        public List<Parameter> Parameters { get; set; }
        public string Path { get; set; }

    }
}