
namespace MSP.BetterCalm.DataAccess.DtoObjects
{
    public abstract class UserDto
    {
        public int UserDtoId { get; set; }
        public string Name { get; set; }
        public string LastName { get; set; }

    }
}